package io.github.asankilp.dys.item;

import net.minecraft.item.Item;
import net.minecraft.item.ItemGroup;

public class DeadIron extends Item {
    public DeadIron() {
        super(new Item.Settings().group(ItemGroup.MATERIALS));
    }
}
