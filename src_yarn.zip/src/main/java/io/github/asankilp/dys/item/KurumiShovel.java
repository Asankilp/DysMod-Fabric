package io.github.asankilp.dys.item;


import net.minecraft.client.item.TooltipContext;
import net.minecraft.entity.EntityGroup;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.*;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.text.TranslatableTextContent;
import net.minecraft.world.World;

import javax.annotation.Nullable;
import java.util.List;

public class KurumiShovel extends ShovelItem {

    public KurumiShovel() {
        super(ToolMaterials.IRON, 6, -3f, (new Item.Settings().group(ItemGroup.TOOLS)));
    }
    /*
     * This method refer to the Botania Mod.
     * Get the Source Code in github:
     * https://github.com/Vazkii/Botania
     *
     * Botania is Open Source and distributed under the
     * Botania License: http://botaniamod.net/license.php
     */
    @Override
    public boolean postHit(ItemStack stack, LivingEntity target, LivingEntity attacker) {
        if (target.getGroup() == EntityGroup.UNDEAD) {
            attacker.world.playSound(null, attacker.getX(), attacker.getY(), attacker.getZ(), SoundEvents.ENTITY_ITEM_BREAK, attacker.getSoundCategory(), 1F, 0.5F);
            target.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 30, 10, true, true));
//            target.addPotionEffect(new EffectInstance(Effects.INSTANT_HEALTH, 1,4));
            if (attacker instanceof PlayerEntity) {
                target.damage(DamageSource.player((PlayerEntity) attacker), getAttackDamage() * 5);
            } else {
                target.damage(DamageSource.mob(attacker), getAttackDamage() * 5);
            }

        }
        return super.postHit(stack, target, attacker);
    }
    @Override
    public void appendTooltip(ItemStack stack, @Nullable World levelIn, List<Text> tooltip, TooltipContext context) {
        tooltip.add((Text) new TranslatableTextContent("item.kurumi_shovel.tip1"));
        tooltip.add((Text) new TranslatableTextContent("item.kurumi_shovel.tip2"));
    }

}
