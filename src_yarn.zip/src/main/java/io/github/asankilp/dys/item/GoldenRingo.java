package io.github.asankilp.dys.item;

import io.github.asankilp.dys.sound.SoundReg;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.FoodComponent;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroup;
import net.minecraft.item.ItemStack;
import net.minecraft.sound.SoundCategory;
import net.minecraft.world.World;

public class GoldenRingo extends Item {
    private static final FoodComponent ringo = (new FoodComponent.Builder())
            .saturationModifier(1.2F)
            .hunger(4)
            .statusEffect((new StatusEffectInstance(StatusEffects.NAUSEA, 114, 514, true, false)), 1)
            .statusEffect((new StatusEffectInstance(StatusEffects.DARKNESS, 114, 514, true, false)), 1)

            .build();

    public GoldenRingo() {
        super(new Settings().food(ringo).group(ItemGroup.FOOD));
    }
    @Override
    public ItemStack finishUsing(ItemStack itemIn, World levelIn, LivingEntity entityIn) {
        levelIn.playSound((PlayerEntity) null, entityIn.getX(), entityIn.getY(), entityIn.getZ(), SoundReg.tokugawaShoutSound.get(), SoundCategory.AMBIENT, 0.5f, 1f);
        return super.finishUsing(itemIn, levelIn, entityIn);
    }
}