package io.github.asankilp.dys.sound;

import io.github.asankilp.dys.Dys;
import io.github.fabricators_of_create.porting_lib.util.LazyRegistrar;
import io.github.fabricators_of_create.porting_lib.util.RegistryObject;
import net.minecraft.sound.SoundEvent;
import net.minecraft.util.Identifier;
import net.minecraft.util.registry.Registry;

public class SoundReg {
    public static final LazyRegistrar<SoundEvent> SOUNDS = LazyRegistrar.create(Registry.SOUND_EVENT, Dys.MODID);
    public static final RegistryObject<SoundEvent> yajuSound = SOUNDS.register("ambient.yaju.shout", ()
            -> new SoundEvent(new Identifier(Dys.MODID, "ambient.yaju.shout")));
    public static final RegistryObject<SoundEvent> yaju_block_placeSound = SOUNDS.register("block.yaju_block.place", ()
            -> new SoundEvent(new Identifier(Dys.MODID, "block.yaju_block.place")));
    public static final RegistryObject<SoundEvent> tokugawaShoutSound = SOUNDS.register("ambient.tokugawa.shout", ()
            -> new SoundEvent(new Identifier(Dys.MODID, "ambient.tokugawa.shout")));
    public static final RegistryObject<SoundEvent> yajuYarimasuSound = SOUNDS.register("ambient.yaju.yarimasu", ()
            -> new SoundEvent(new Identifier(Dys.MODID, "ambient.yaju.yarimasu")));
    public static final RegistryObject<SoundEvent> akariakarinSound = SOUNDS.register("ambient.akaza_akari.akarin", ()
            -> new SoundEvent(new Identifier(Dys.MODID, "ambient.akaza_akari.akarin")));
}
