package io.github.asankilp.dys.item;

import net.minecraft.block.Block;
import net.minecraft.block.Material;

public class YajuBlock extends Block {
    public YajuBlock() {
        super(Settings.of(Material.STONE));
    }

}