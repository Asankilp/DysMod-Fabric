package io.github.asankilp.dys.item;

import io.github.asankilp.dys.sound.SoundReg;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.world.World;

public class Yaju extends Item {
    public Yaju() {
        super(new Settings());
    }
    @Override
    public TypedActionResult<ItemStack> use(World levelIn, PlayerEntity playerIn, Hand handIn) {
        if (levelIn.isClient) {
            levelIn.playSound(playerIn, playerIn.getX(), playerIn.getY(), playerIn.getZ(), SoundReg.yajuSound.get(), playerIn.getSoundCategory(), 10F, 1F);
        }
        return super.use(levelIn, playerIn, handIn);
        }
}
