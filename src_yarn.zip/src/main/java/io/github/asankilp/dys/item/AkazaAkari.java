package io.github.asankilp.dys.item;

import io.github.asankilp.dys.sound.SoundReg;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.sound.SoundCategory;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.world.World;

public class AkazaAkari extends Item {
    public AkazaAkari() {
        super(new Settings());

    }
    @Override
    public TypedActionResult<ItemStack> use(World levelIn, PlayerEntity playerIn, Hand handIn) {
        ItemStack stack = playerIn.getStackInHand(handIn);
        playerIn.addStatusEffect(new StatusEffectInstance(StatusEffects.INVISIBILITY, 140, 4, true, false));
        playerIn.getItemCooldownManager().set(this, 190);
        levelIn.playSound((PlayerEntity) null, playerIn.getX(), playerIn.getY(), playerIn.getZ(), SoundReg.akariakarinSound.get(), SoundCategory.AMBIENT.AMBIENT, 0.5f, 1f);
        if(!playerIn.getAbilities().creativeMode) {
            stack.decrement(1);
        }
        return super.use(levelIn, playerIn, handIn);
    }
}
